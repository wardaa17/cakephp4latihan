<!-- src/Template/Users/index.ctp -->
<div class="users form content">
    <?= $this->Flash->render() ?>
    <?= $this->Form->create() ?>
        <fieldset>
            <legend><?= __('Login') ?></legend>
            <?= $this->Form->control('username', ['label' => 'Username']) ?>
            <?= $this->Form->control('password', ['label' => 'Password']) ?>
        </fieldset>
        <?= $this->Form->button(__('Login')) ?>
    <?= $this->Form->end() ?>
</div>