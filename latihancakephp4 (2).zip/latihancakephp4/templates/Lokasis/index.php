<?php
/**
 * @var \App\View\AppView $this
 * @var iterable<\App\Model\Entity\Lokasi> $lokasis
 */
?>
<div class="lokasis index content">
    <?= $this->Html->link(__('New Lokasi'), ['action' => 'add'], ['class' => 'button float-right']) ?>
    <h3><?= __('Lokasis') ?></h3>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('id') ?></th>
                    <th><?= $this->Paginator->sort('nama_lokasi') ?></th>
                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($lokasis as $lokasi): ?>
                <tr>
                    <td><?= h($lokasi->id) ?></td>
                    <td><?= h($lokasi->nama_lokasi) ?></td>
                    <td class="actions">
                        <?= $this->Html->link(__('View'), ['action' => 'view', $lokasi->id]) ?>
                        <?= $this->Html->link(__('Edit'), ['action' => 'edit', $lokasi->id]) ?>
                        <?= $this->Form->postLink(__('Delete'), ['action' => 'delete', $lokasi->id], ['confirm' => __('Are you sure you want to delete # {0}?', $lokasi->id)]) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="paginator">
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('first')) ?>
            <?= $this->Paginator->prev('< ' . __('previous')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('next') . ' >') ?>
            <?= $this->Paginator->last(__('last') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Page {{page}} of {{pages}}, showing {{current}} record(s) out of {{count}} total')) ?></p>
    </div>
</div>
