<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Lokasi $lokasi
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit Lokasi'), ['action' => 'edit', $lokasi->id], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete Lokasi'), ['action' => 'delete', $lokasi->id], ['confirm' => __('Are you sure you want to delete # {0}?', $lokasi->id), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List Lokasis'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New Lokasi'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="lokasis view content">
            <h3><?= h($lokasi->nama_lokasi) ?></h3>
            <table>
                <tr>
                    <th><?= __('Id') ?></th>
                    <td><?= h($lokasi->id) ?></td>
                </tr>
                <tr>
                    <th><?= __('Nama Lokasi') ?></th>
                    <td><?= h($lokasi->nama_lokasi) ?></td>
                </tr>
            </table>
        </div>
    </div>
</div>
