<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Departemen $departemen
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit Departemen'), ['action' => 'edit', $departemen->id], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete Departemen'), ['action' => 'delete', $departemen->id], ['confirm' => __('Are you sure you want to delete # {0}?', $departemen->id), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List Departemens'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New Departemen'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="departemens view content">
            <h3><?= h($departemen->departemen) ?></h3>
            <table>
                <tr>
                    <th><?= __('Id') ?></th>
                    <td><?= h($departemen->id) ?></td>
                </tr>
                <tr>
                    <th><?= __('Departemen') ?></th>
                    <td><?= h($departemen->departemen) ?></td>
                </tr>
            </table>
        </div>
    </div>
</div>
