<?php
/**
 * @var \App\View\AppView $this
 * @var iterable<\App\Model\Entity\Departemen> $departemens
 */
?>
<div class="departemens index content">
    <?= $this->Html->link(__('New Departemen'), ['action' => 'add'], ['class' => 'button float-right']) ?>
    <h3><?= __('Departemen') ?></h3>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('departemen') ?></th>
                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($departemens as $departemen): ?>
                <tr>
                    <td><?= h($departemen->departemen) ?></td>
                    <td class="actions">
                        <?= $this->Html->link(__('View'), ['action' => 'view', $departemen->id]) ?>
                        <?= $this->Html->link(__('Edit'), ['action' => 'edit', $departemen->id]) ?>
                        <?= $this->Form->postLink(__('Delete'), ['action' => 'delete', $departemen->id], ['confirm' => __('Are you sure you want to delete # {0}?', $departemen->id)]) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="paginator">
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('first')) ?>
            <?= $this->Paginator->prev('< ' . __('previous')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('next') . ' >') ?>
            <?= $this->Paginator->last(__('last') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Page {{page}} of {{pages}}, showing {{current}} record(s) out of {{count}} total')) ?></p>
    </div>
</div>
