<?php
/**
 * @var \App\View\AppView $this
 * @var iterable<\App\Model\Entity\Mobil> $mobils
 */
?>
<div class="mobils index content">
    <?= $this->Html->link(__('New Mobil'), ['action' => 'add'], ['class' => 'button float-right']) ?>
    <h3><?= __('Mobil') ?></h3>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('nopol_mobil') ?></th>
                    <th><?= $this->Paginator->sort('nama_mobil') ?></th>
                    <th><?= $this->Paginator->sort('type_mobil') ?></th>
                    <th><?= $this->Paginator->sort('kapasitas') ?></th>

                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($mobils as $mobil): ?>
                <tr>
                    <td><?= h($mobil->nopol_mobil) ?></td>
                    <td><?= h($mobil->nama_mobil) ?></td>
                    <td><?= h($mobil->type_mobil) ?></td>
                    <td><?= h($mobil->kapasitas) ?></td>
                    <td class="actions">
                        <?= $this->Html->link(__('View'), ['action' => 'view', $mobil->id]) ?>
                        <?= $this->Html->link(__('Edit'), ['action' => 'edit', $mobil->id]) ?>
                        <?= $this->Form->postLink(__('Delete'), ['action' => 'delete', $mobil->id], ['confirm' => __('Are you sure you want to delete # {0}?', $mobil->id)]) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="paginator">
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('first')) ?>
            <?= $this->Paginator->prev('< ' . __('previous')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('next') . ' >') ?>
            <?= $this->Paginator->last(__('last') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Page {{page}} of {{pages}}, showing {{current}} record(s) out of {{count}} total')) ?></p>
    </div>
</div>
