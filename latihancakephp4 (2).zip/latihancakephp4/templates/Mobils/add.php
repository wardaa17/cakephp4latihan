<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Mobil $mobil
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('List Mobils'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="mobils form content">
            <?= $this->Form->create($mobil) ?>
            <fieldset>
                <legend><?= __('Add Mobil') ?></legend>
                <?php
                    echo $this->Form->control('nopol_mobil');
                    echo $this->Form->control('nama_mobil');
                    echo $this->Form->control('type_mobil');
                    echo $this->Form->control('kapasitas');
                    
                ?>
            </fieldset>
            <?= $this->Form->button(__('Submit')) ?>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>
