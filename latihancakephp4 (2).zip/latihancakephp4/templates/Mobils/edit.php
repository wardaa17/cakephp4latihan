<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Mobil $mobil
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Form->postLink(
                __('Delete'),
                ['action' => 'delete', $mobil->id],
                ['confirm' => __('Are you sure you want to delete # {0}?', $mobil->id), 'class' => 'side-nav-item']
            ) ?>
            <?= $this->Html->link(__('List Mobils'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="mobils form content">
            <?= $this->Form->create($mobil) ?>
            <fieldset>
                <legend><?= __('Edit Mobil') ?></legend>
                <?php
                    echo $this->Form->control('nopol_mobil');
                    echo $this->Form->control('nama_mobil');
                    echo $this->Form->control('type_mobil');
                    echo $this->Form->control('kapasitas');
                ?>
            </fieldset>
            <?= $this->Form->button(__('Submit')) ?>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>
