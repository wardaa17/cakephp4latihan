<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Mobil $mobil
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit Mobil'), ['action' => 'edit', $mobil->id], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete Mobil'), ['action' => 'delete', $mobil->id], ['confirm' => __('Are you sure you want to delete # {0}?', $mobil->id), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List Mobils'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New Mobil'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="mobils view content">
            <h3><?= h($mobil->nopol_mobil) ?></h3>
            <table>
                <tr>
                    <th><?= __('Id') ?></th>
                    <td><?= $this->Number->format($mobil->id) ?></td>
                </tr>
                <tr>
                    <th><?= __('Nopol Mobil') ?></th>
                    <td><?= h($mobil->nopol_mobil) ?></td>
                </tr>
                <tr>
                    <th><?= __('Nama Mobil') ?></th>
                    <td><?= h($mobil->nama_mobil) ?></td>
                </tr>
                <tr>
                    <th><?= __('Type Mobil') ?></th>
                    <td><?= h($mobil->type_mobil) ?></td>
                </tr>
                <tr>
                    <th><?= __('Kapasitas') ?></th>
                    <td><?= h($mobil->kapasitas) ?></td>
                </tr>
            </table>
        </div>
    </div>
</div>
