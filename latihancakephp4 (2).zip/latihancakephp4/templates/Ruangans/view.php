<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Ruangan $ruangan
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit Ruangan'), ['action' => 'edit', $ruangan->id], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete Ruangan'), ['action' => 'delete', $ruangan->id], ['confirm' => __('Are you sure you want to delete # {0}?', $ruangan->id), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List Ruangans'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New Ruangan'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="ruangans view content">
            <h3><?= h($ruangan->nama_ruangan) ?></h3>
            <table>
                <tr>
                    <th><?= __('Id') ?></th>
                    <td><?= h($ruangan->id) ?></td>
                </tr>
                <tr>
                    <th><?= __('Nama Ruangan') ?></th>
                    <td><?= h($ruangan->nama_ruangan) ?></td>
                </tr>
            </table>
            <div class="text">
                <strong><?= __('Deskripsi') ?></strong>
                <blockquote>
                    <?= $this->Text->autoParagraph(h($ruangan->deskripsi)); ?>
                </blockquote>
            </div>
        </div>
    </div>
</div>
