<?php
/**
 * @var \App\View\AppView $this
 * @var iterable<\App\Model\Entity\Peminjamanmobil> $peminjamanmobil
 */
?>
<div class="peminjamanmobil index content">
    <?= $this->Html->link(__('New Peminjaman Mobil'), ['action' => 'add'], ['class' => 'button float-right']) ?>
    <h3><?= __('Peminjaman Mobil') ?></h3>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('status_driver') ?></th>
                    <th><?= $this->Paginator->sort('tanggal_pinjam') ?></th>
                    <th><?= $this->Paginator->sort('waktu_pinjam') ?></th>
                    <th><?= $this->Paginator->sort('nama_peminjam') ?></th>
                    <th><?= $this->Paginator->sort('Jumlah Penumpang') ?></th>
                    <th><?= $this->Paginator->sort('created') ?></th>
                    <th><?= $this->Paginator->sort('Departemen') ?></th>
                    <th><?= $this->Paginator->sort('Tujuan Lokasi') ?></th>
                    <th><?= $this->Paginator->sort('Nama Driver') ?></th>
                    <th><?= $this->Paginator->sort('Nama Mobil') ?></th>
                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($peminjamanmobil as $peminjamanmobil): ?>

                <tr>
                    <td><?= h($peminjamanmobil->status_driver) ?></td>
                    <td><?= h($peminjamanmobil->tanggal_pinjam) ?></td>
                    <td><?= h($peminjamanmobil->waktu_pinjam) ?></td>
                    <td><?= h($peminjamanmobil->nama_peminjam) ?></td>
                    <td><?= $this->Number->format($peminjamanmobil->penumpang) ?></td>
                    <td><?= h($peminjamanmobil->created) ?></td>
                    <td><?= h($peminjamanmobil->departemen->nama_departemen) ?></td>
                    <td><?= h($peminjamanmobil->lokasi->nama_lokasi) ?></td>
                    <td><?= h($peminjamanmobil->driver->nama_driver) ?></td>
                    <td><?= h($peminjamanmobil->mobil->nama_mobil) ?></td>
                    <td class="actions">
                        <?= $this->Html->link(__('View'), ['action' => 'view', $peminjamanmobil->id]) ?>
                        <?= $this->Html->link(__('Edit'), ['action' => 'edit', $peminjamanmobil->id]) ?>
                        <?= $this->Form->postLink(__('Delete'), ['action' => 'delete', $peminjamanmobil->id], ['confirm' => __('Are you sure you want to delete # {0}?', $peminjamanmobil->id)]) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="paginator">
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('first')) ?>
            <?= $this->Paginator->prev('< ' . __('previous')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('next') . ' >') ?>
            <?= $this->Paginator->last(__('last') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Page {{page}} of {{pages}}, showing {{current}} record(s) out of {{count}} total')) ?></p>
    </div>
</div>
