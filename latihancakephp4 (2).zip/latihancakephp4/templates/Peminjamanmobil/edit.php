<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Peminjamanmobil $peminjamanmobil
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Form->postLink(
                __('Delete'),
                ['action' => 'delete', $peminjamanmobil->id],
                ['confirm' => __('Are you sure you want to delete # {0}?', $peminjamanmobil->id), 'class' => 'side-nav-item']
            ) ?>
            <?= $this->Html->link(__('List Peminjamanmobil'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="peminjamanmobil form content">
            <?= $this->Form->create($peminjamanmobil) ?>
            <fieldset>
                <legend><?= __('Edit Peminjamanmobil') ?></legend>
                <?php
                    echo $this->Form->control('status_driver');
                    echo $this->Form->control('tanggal_pinjam');
                    echo $this->Form->control('waktu_pinjam');
                    echo $this->Form->control('nama_peminjam');
                    echo $this->Form->control('tujuan');
                    echo $this->Form->control('deskripsi');
                    echo $this->Form->control('penumpang');
                    echo $this->Form->control('id_departemen');
                    echo $this->Form->control('id_lokasi');
                    echo $this->Form->control('id_driver');
                    echo $this->Form->control('id_mobil');
                ?>
            </fieldset>
            <?= $this->Form->button(__('Submit')) ?>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>
