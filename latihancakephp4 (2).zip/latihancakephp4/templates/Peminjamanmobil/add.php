<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Peminjamanmobil $peminjamanmobil
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('List Peminjamanmobil'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="peminjamanmobil form content">
            <?= $this->Form->create($peminjamanmobil) ?>
            <fieldset>
                <legend><?= __('Add Peminjamanmobil') ?></legend>
                <?php
                    echo $this->Form->control('status_driver',['options'=>["Ya"=>'Ya', "Tidak"=>'Tidak'], 'type'=>"select",'id'=>'status_driver']);
                    echo $this->Form->control('tanggal_pinjam',['type'=>"date"]);
                    echo $this->Form->control('waktu_pinjam',['type'=>"time",'class'=>'control']);
                    echo $this->Form->control('nama_peminjam');
                    echo $this->Form->control('tujuan');
                    echo $this->Form->control('deskripsi');
                    echo $this->Form->control('penumpang');
                    echo $this->Form->label('Nama Departemen');
                    echo $this->Form->select('id_departemen', $departemens, ['empty'=>"Pilih Departemen"]);
                    echo $this->Form->label('Tujuan Lokasi');
                    echo $this->Form->select('id_lokasi', $lokasis, ['empty'=>"Pilih Tujuan Lokasi"]);
                    echo $this->Form->label('Nama Driver');
                    echo $this->Form->select('id_driver', $drivers, ['empty'=>"Pilih Driver"]);
                    echo $this->Form->label('Nama Mobil');
                    echo $this->Form->select('id_mobil', $mobils, ['empty'=>"Pilih Mobil"]);
                  
                ?>
            </fieldset>
            <?= $this->Form->button(__('Submit')) ?>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>
