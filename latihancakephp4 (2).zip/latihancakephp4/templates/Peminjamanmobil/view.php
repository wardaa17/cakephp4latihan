<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Peminjamanmobil $peminjamanmobil
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit Peminjamanmobil'), ['action' => 'edit', $peminjamanmobil->id], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete Peminjamanmobil'), ['action' => 'delete', $peminjamanmobil->id], ['confirm' => __('Are you sure you want to delete # {0}?', $peminjamanmobil->id), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List Peminjamanmobil'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New Peminjamanmobil'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="peminjamanmobil view content">
            <h3><?= h($peminjamanmobil->status_driver) ?></h3>
            <table>
                <tr>
                    <th><?= __('Id') ?></th>
                    <td><?= h($peminjamanmobil->id) ?></td>
                </tr>
                <tr>
                    <th><?= __('Status Driver') ?></th>
                    <td><?= h($peminjamanmobil->status_driver) ?></td>
                </tr>
                <tr>
                    <th><?= __('Nama Peminjam') ?></th>
                    <td><?= h($peminjamanmobil->nama_peminjam) ?></td>
                </tr>
                <tr>
                    <th><?= __('Penumpang') ?></th>
                    <td><?= h($peminjamanmobil->penumpang) ?></td>
                </tr>
                <tr>
                    <th><?= __('Tanggal Pinjam') ?></th>
                    <td><?= h($peminjamanmobil->tanggal_pinjam) ?></td>
                </tr>
                <tr>
                    <th><?= __('Waktu Pinjam') ?></th>
                    <td><?= h($peminjamanmobil->waktu_pinjam) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id Departemen') ?></th>
                    <td><?= h($peminjamanmobil->id_departemen) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id Lokasi') ?></th>
                    <td><?= h($peminjamanmobil->id_lokasi) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id Driver') ?></th>
                    <td><?= h($peminjamanmobil->id_driver) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id Mobil') ?></th>
                    <td><?= h($peminjamanmobil->id_mobil) ?></td>
                </tr>
                <tr>
                    <th><?= __('Created') ?></th>
                    <td><?= h($peminjamanmobil->created) ?></td>
                </tr>
            </table>
            <div class="text">
                <strong><?= __('Deskripsi') ?></strong>
                <blockquote>
                    <?= $this->Text->autoParagraph(h($peminjamanmobil->deskripsi)); ?>
                </blockquote>
            </div>
        </div>
    </div>
</div>
