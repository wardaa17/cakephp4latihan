<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Peminjamanruang $peminjamanruang
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit Peminjamanruang'), ['action' => 'edit', $peminjamanruang->id_ruang], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete Peminjamanruang'), ['action' => 'delete', $peminjamanruang->id_ruang], ['confirm' => __('Are you sure you want to delete # {0}?', $peminjamanruang->id_ruang), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List Peminjamanruang'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New Peminjamanruang'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="peminjamanruang view content">
            <h3><?= h($peminjamanruang->nama_peminjam) ?></h3>
            <table>
                <tr>
                    <th><?= __('Nama Ruangan') ?></th>
                    <td><?= h($peminjamanruang->id_ruang) ?></td>
                </tr>
                <tr>
                    <th><?= __('Nama Departemen Departemen') ?></th>
                    <td><?= h($peminjamanruang->id_departemen) ?></td>
                </tr>
                <tr>
                    <th><?= __('Nama Peminjam') ?></th>
                    <td><?= h($peminjamanruang->nama_peminjam) ?></td>
                </tr>
                <tr>
                    <th><?= __('Status') ?></th>
                    <td><?= h($peminjamanruang->status) ?></td>
                </tr>
                <tr>
                    <th><?= __('Waktu Selesai') ?></th>
                    <td><?= $this->Number->format($peminjamanruang->waktu_selesai) ?></td>
                </tr>
                <tr>
                    <th><?= __('Tujuan') ?></th>
                    <td><?= $this->Number->format($peminjamanruang->tujuan) ?></td>
                </tr>
                <tr>
                    <th><?= __('Jumlah Pengguna') ?></th>
                    <td><?= $this->Number->format($peminjamanruang->jumlah_pengguna) ?></td>
                </tr>
                <tr>
                    <th><?= __('Penginput') ?></th>
                    <td><?= $this->Number->format($peminjamanruang->penginput) ?></td>
                </tr>
                <tr>
                    <th><?= __('Email') ?></th>
                    <td><?= $this->Number->format($peminjamanruang->email) ?></td>
                </tr>
                <tr>
                    <th><?= __('Tanggal Pakai') ?></th>
                    <td><?= h($peminjamanruang->tanggal_pakai) ?></td>
                </tr>
                <tr>
                    <th><?= __('Waktu Pakai') ?></th>
                    <td><?= h($peminjamanruang->waktu_pakai) ?></td>
                </tr>
            </table>
        </div>
    </div>
</div>
