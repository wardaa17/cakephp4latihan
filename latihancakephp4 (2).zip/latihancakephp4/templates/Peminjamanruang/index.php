<?php
/**
 * @var \App\View\AppView $this
 * @var iterable<\App\Model\Entity\Peminjamanruang> $peminjamanruang
 */
?>
<div class="peminjamanruang index content">
    <?= $this->Html->link(__('New Peminjaman Ruang'), ['action' => 'add'], ['class' => 'button float-right']) ?>
    <h3><?= __('Peminjaman Ruang') ?></h3>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('id') ?></th>
                    <th><?= $this->Paginator->sort('nama_ruangan') ?></th>
                    <th><?= $this->Paginator->sort('nama_departemen') ?></th>
                    <th><?= $this->Paginator->sort('nama_peminjam') ?></th>
                    <th><?= $this->Paginator->sort('tanggal_pakai') ?></th>
                    <th><?= $this->Paginator->sort('waktu_pakai') ?></th>
                    <th><?= $this->Paginator->sort('waktu_selesai') ?></th>
                    <th><?= $this->Paginator->sort('tujuan') ?></th>
                    <th><?= $this->Paginator->sort('jumlah_pengguna') ?></th>
                    <th><?= $this->Paginator->sort('status') ?></th>
                    <th><?= $this->Paginator->sort('penginput') ?></th>
                    <th><?= $this->Paginator->sort('email') ?></th>
                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($peminjamanruangs as $peminjamanruang): ?>
                <tr>
                    <td><?= h($peminjamanruang->id) ?></td>
                    <td><?= h($peminjamanruang->ruangan->nama_ruangan) ?></td>
                    <td><?= h($peminjamanruang->departemen->nama_departemen) ?></td>
                    <td><?= h($peminjamanruang->nama_peminjam) ?></td>
                    <td><?= h($peminjamanruang->tanggal_pakai) ?></td>
                    <td><?= h($peminjamanruang->waktu_pakai) ?></td>
                    <td><?= $this->Number->format($peminjamanruang->waktu_selesai) ?></td>
                    <td><?= $this->Number->format($peminjamanruang->tujuan) ?></td>
                    <td><?= $this->Number->format($peminjamanruang->jumlah_pengguna) ?></td>
                    <td><?= h($peminjamanruang->status) ?></td>
                    <td><?= $this->Number->format($peminjamanruang->penginput) ?></td>
                    <td><?= $this->Number->format($peminjamanruang->email) ?></td>
                    <td class="actions">
                        <?= $this->Html->link(__('View'), ['action' => 'view', $peminjamanruang->id]) ?>
                        <?= $this->Html->link(__('Edit'), ['action' => 'edit', $peminjamanruang->id]) ?>
                        <?= $this->Form->postLink(__('Delete'), ['action' => 'delete', $peminjamanruang->id], ['confirm' => __('Are you sure you want to delete # {0}?', $peminjamanruang->id_ruang)]) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="paginator">
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('first')) ?>
            <?= $this->Paginator->prev('< ' . __('previous')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('next') . ' >') ?>
            <?= $this->Paginator->last(__('last') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Page {{page}} of {{pages}}, showing {{current}} record(s) out of {{count}} total')) ?></p>
    </div>
</div>
