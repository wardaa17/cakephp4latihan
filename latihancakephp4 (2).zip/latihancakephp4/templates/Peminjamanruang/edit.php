<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Peminjamanruang $peminjamanruang
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Form->postLink(
                __('Delete'),
                ['action' => 'delete', $peminjamanruang->id_ruang],
                ['confirm' => __('Are you sure you want to delete # {0}?', $peminjamanruang->id_ruang), 'class' => 'side-nav-item']
            ) ?>
            <?= $this->Html->link(__('List Peminjamanruang'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="peminjamanruang form content">
            <?= $this->Form->create($peminjamanruang) ?>
            <fieldset>
                <legend><?= __('Edit Peminjamanruang') ?></legend>
                <?php
                    echo $this->Form->control('nama_peminjam');
                    echo $this->Form->control('tanggal_pakai');
                    echo $this->Form->control('waktu_pakai');
                    echo $this->Form->control('waktu_selesai');
                    echo $this->Form->control('tujuan');
                    echo $this->Form->control('jumlah_pengguna');
                    echo $this->Form->control('status');
                    echo $this->Form->control('penginput');
                    echo $this->Form->control('email');
                ?>
            </fieldset>
            <?= $this->Form->button(__('Submit')) ?>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>
