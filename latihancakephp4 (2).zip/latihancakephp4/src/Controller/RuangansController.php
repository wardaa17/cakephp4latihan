<?php
declare(strict_types=1);

namespace App\Controller;

/**
 * Ruangans Controller
 *
 * @property \App\Model\Table\RuangansTable $Ruangans
 * @method \App\Model\Entity\Ruangan[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class RuangansController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function index()
    {
        
        $ruangans = $this->paginate($this->Ruangans);

        $this->set(compact('ruangans'));
    }

    /**
     * View method
     *
     * @param string|null $id Ruangan id.
     * @return \Cake\Http\Response|null|void Renders view
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $ruangan = $this->Ruangans->get($id, [
            'contain' => [],
        ]);

        $this->set(compact('ruangan'));
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $ruangan = $this->Ruangans->newEmptyEntity();
        if ($this->request->is('post')) {
            $ruangan = $this->Ruangans->patchEntity($ruangan, $this->request->getData());
            if ($this->Ruangans->save($ruangan)) {
                $this->Flash->success(__('The ruangan has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The ruangan could not be saved. Please, try again.'));
        }
        $this->set(compact('ruangan'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Ruangan id.
     * @return \Cake\Http\Response|null|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $ruangan = $this->Ruangans->get($id, [
            'contain' => [],
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $ruangan = $this->Ruangans->patchEntity($ruangan, $this->request->getData());
            if ($this->Ruangans->save($ruangan)) {
                $this->Flash->success(__('The ruangan has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The ruangan could not be saved. Please, try again.'));
        }
        $this->set(compact('ruangan'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Ruangan id.
     * @return \Cake\Http\Response|null|void Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $ruangan = $this->Ruangans->get($id);
        if ($this->Ruangans->delete($ruangan)) {
            $this->Flash->success(__('The ruangan has been deleted.'));
        } else {
            $this->Flash->error(__('The ruangan could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
