<?php
declare(strict_types=1);

namespace App\Controller;

/**
 * Mobils Controller
 *
 * @property \App\Model\Table\MobilsTable $Mobils
 * @method \App\Model\Entity\Mobil[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class MobilsController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function index()
    {
        $mobils = $this->paginate($this->Mobils);

        $this->set(compact('mobils'));
    }

    /**
     * View method
     *
     * @param string|null $id Mobil id.
     * @return \Cake\Http\Response|null|void Renders view
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $mobil = $this->Mobils->get($id, [
            'contain' => [],
        ]);

        $this->set(compact('mobil'));
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $mobil = $this->Mobils->newEmptyEntity();
        if ($this->request->is('post')) {
            $mobil = $this->Mobils->patchEntity($mobil, $this->request->getData());
            if ($this->Mobils->save($mobil)) {
                $this->Flash->success(__('The mobil has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The mobil could not be saved. Please, try again.'));
        }
        $this->set(compact('mobil'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Mobil id.
     * @return \Cake\Http\Response|null|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $mobil = $this->Mobils->get($id, [
            'contain' => [],
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $mobil = $this->Mobils->patchEntity($mobil, $this->request->getData());
            if ($this->Mobils->save($mobil)) {
                $this->Flash->success(__('The mobil has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The mobil could not be saved. Please, try again.'));
        }
        $this->set(compact('mobil'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Mobil id.
     * @return \Cake\Http\Response|null|void Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $mobil = $this->Mobils->get($id);
        if ($this->Mobils->delete($mobil)) {
            $this->Flash->success(__('The mobil has been deleted.'));
        } else {
            $this->Flash->error(__('The mobil could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
