<?php
declare(strict_types=1);

namespace App\Controller;
use Cake\ORM\TableRegistry;

/**
 * Peminjamanruang Controller
 *
 * @property \App\Model\Table\PeminjamanruangTable $Peminjamanruang
 * @method \App\Model\Entity\Peminjamanruang[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class PeminjamanruangController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function index()
    {
        $this->paginate = [
            'contain'=> ['Ruangans']
        ];

        $peminjamanruang = $this->paginate($this->Peminjamanruang);

        $this->set(compact('peminjamanruang'));
    }

    /**
     * View method
     *
     * @param string|null $id Peminjamanruang id.
     * @return \Cake\Http\Response|null|void Renders view
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $peminjamanruang = $this->Peminjamanruang->get($id, [
            'contain' => [],
        ]);

        $this->set(compact('peminjamanruang'));
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $peminjamanruang = $this->Peminjamanruang->newEmptyEntity();
        if ($this->request->is('post')) {
            $peminjamanruang = $this->Peminjamanruang->patchEntity($peminjamanruang, $this->request->getData());
            if ($this->Peminjamanruang->save($peminjamanruang)) {
                $this->Flash->success(__('The peminjamanruang has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The peminjamanruang could not be saved. Please, try again.'));
        }

        $ruangansTable = TableRegistry::getTableLocator()->get('Ruangans');
        $ruangans = $ruangansTable->find('list')->toArray();

        $this->set(compact('peminjamanruang','ruangans','departemens'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Peminjamanruang id.
     * @return \Cake\Http\Response|null|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $peminjamanruang = $this->Peminjamanruang->get($id, [
            'contain' => [],
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $peminjamanruang = $this->Peminjamanruang->patchEntity($peminjamanruang, $this->request->getData());
            if ($this->Peminjamanruang->save($peminjamanruang)) {
                $this->Flash->success(__('The peminjamanruang has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The peminjamanruang could not be saved. Please, try again.'));
        }
        $this->set(compact('peminjamanruang'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Peminjamanruang id.
     * @return \Cake\Http\Response|null|void Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $peminjamanruang = $this->Peminjamanruang->get($id);
        if ($this->Peminjamanruang->delete($peminjamanruang)) {
            $this->Flash->success(__('The peminjamanruang has been deleted.'));
        } else {
            $this->Flash->error(__('The peminjamanruang could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
