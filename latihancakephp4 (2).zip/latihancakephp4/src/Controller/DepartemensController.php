<?php
declare(strict_types=1);

namespace App\Controller;

/**
 * Departemens Controller
 *
 * @property \App\Model\Table\DepartemensTable $Departemens
 * @method \App\Model\Entity\Departemen[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class DepartemensController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function index()
    {
        $departemens = $this->paginate($this->Departemens);

        $this->set(compact('departemens'));
    }

    /**
     * View method
     *
     * @param string|null $id Departemen id.
     * @return \Cake\Http\Response|null|void Renders view
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $departemen = $this->Departemens->get($id, [
            'contain' => [],
        ]);

        $this->set(compact('departemen'));
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $departemen = $this->Departemens->newEmptyEntity();
        if ($this->request->is('post')) {
            $departemen = $this->Departemens->patchEntity($departemen, $this->request->getData());
            if ($this->Departemens->save($departemen)) {
                $this->Flash->success(__('The departemen has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The departemen could not be saved. Please, try again.'));
        }
        $this->set(compact('departemen'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Departemen id.
     * @return \Cake\Http\Response|null|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $departemen = $this->Departemens->get($id, [
            'contain' => [],
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $departemen = $this->Departemens->patchEntity($departemen, $this->request->getData());
            if ($this->Departemens->save($departemen)) {
                $this->Flash->success(__('The departemen has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The departemen could not be saved. Please, try again.'));
        }
        $this->set(compact('departemen'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Departemen id.
     * @return \Cake\Http\Response|null|void Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $departemen = $this->Departemens->get($id);
        if ($this->Departemens->delete($departemen)) {
            $this->Flash->success(__('The departemen has been deleted.'));
        } else {
            $this->Flash->error(__('The departemen could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
