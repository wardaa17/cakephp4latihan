<?php
declare(strict_types=1);

namespace App\Controller;

/**
 * Lokasis Controller
 *
 * @property \App\Model\Table\LokasisTable $Lokasis
 * @method \App\Model\Entity\Lokasi[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class LokasisController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function index()
    {
        $lokasis = $this->paginate($this->Lokasis);

        $this->set(compact('lokasis'));
    }

    /**
     * View method
     *
     * @param string|null $id Lokasi id.
     * @return \Cake\Http\Response|null|void Renders view
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $lokasi = $this->Lokasis->get($id, [
            'contain' => [],
        ]);

        $this->set(compact('lokasi'));
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $lokasi = $this->Lokasis->newEmptyEntity();
        if ($this->request->is('post')) {
            $lokasi = $this->Lokasis->patchEntity($lokasi, $this->request->getData());
            if ($this->Lokasis->save($lokasi)) {
                $this->Flash->success(__('The lokasi has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The lokasi could not be saved. Please, try again.'));
        }
        $this->set(compact('lokasi'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Lokasi id.
     * @return \Cake\Http\Response|null|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $lokasi = $this->Lokasis->get($id, [
            'contain' => [],
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $lokasi = $this->Lokasis->patchEntity($lokasi, $this->request->getData());
            if ($this->Lokasis->save($lokasi)) {
                $this->Flash->success(__('The lokasi has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The lokasi could not be saved. Please, try again.'));
        }
        $this->set(compact('lokasi'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Lokasi id.
     * @return \Cake\Http\Response|null|void Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $lokasi = $this->Lokasis->get($id);
        if ($this->Lokasis->delete($lokasi)) {
            $this->Flash->success(__('The lokasi has been deleted.'));
        } else {
            $this->Flash->error(__('The lokasi could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
