<?php
declare(strict_types=1);

namespace App\Controller;
use Cake\ORM\TableRegistry;
/**
 * Peminjamanmobil Controller
 *
 * @property \App\Model\Table\PeminjamanmobilTable $Peminjamanmobil
 * @method \App\Model\Entity\Peminjamanmobil[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class PeminjamanmobilController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Departemens','Lokasis','Drivers','Mobils']
        ];

        $peminjamanmobil = $this->paginate($this->Peminjamanmobil);

        $this->set(compact('peminjamanmobil'));
    }

    /**
     * View method
     *
     * @param string|null $id Peminjamanmobil id.
     * @return \Cake\Http\Response|null|void Renders view
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $peminjamanmobil = $this->Peminjamanmobil->get($id, [
            'contain' => [],
        ]);

        $this->set(compact('peminjamanmobil'));
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $peminjamanmobil = $this->Peminjamanmobil->newEmptyEntity();
        if ($this->request->is('post')) {
            $peminjamanmobil = $this->Peminjamanmobil->patchEntity($peminjamanmobil, $this->request->getData());
            if ($this->Peminjamanmobil->save($peminjamanmobil)) {
                $this->Flash->success(__('The peminjamanmobil has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The peminjamanmobil could not be saved. Please, try again.'));
        }

        $departemensTable = TableRegistry::getTableLocator()->get('Departemens');
        $departemens = $departemensTable->find('list',['valueField' => 'nama_departemen'])->toArray();

        $lokasisTable = TableRegistry::getTableLocator()->get('Lokasis');
        $lokasis = $lokasisTable->find('list',['valueField' => 'nama_lokasi'])->toArray();

        $driversTable = TableRegistry::getTableLocator()->get('Drivers');
        $drivers = $driversTable->find('list',['valueField' => 'nama_driver'])->toArray();

        $mobilsTable = TableRegistry::getTableLocator()->get('Mobils');
        $mobils = $mobilsTable->find('list')->toArray();
        $mobils = $mobilsTable->find('list',['valueField' => 'nama_mobil'])->toArray();

        $this->set(compact('peminjamanmobil','departemens','lokasis','drivers','mobils'));

    }

    /**
     * Edit method
     *
     * @param string|null $id Peminjamanmobil id.
     * @return \Cake\Http\Response|null|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $peminjamanmobil = $this->Peminjamanmobil->get($id, [
            'contain' => [],
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $peminjamanmobil = $this->Peminjamanmobil->patchEntity($peminjamanmobil, $this->request->getData());
            if ($this->Peminjamanmobil->save($peminjamanmobil)) {
                $this->Flash->success(__('The peminjamanmobil has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The peminjamanmobil could not be saved. Please, try again.'));
        }
        $this->set(compact('peminjamanmobil'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Peminjamanmobil id.
     * @return \Cake\Http\Response|null|void Redirects to index.
     * 
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $peminjamanmobil = $this->Peminjamanmobil->get($id);
        if ($this->Peminjamanmobil->delete($peminjamanmobil)) {
            $this->Flash->success(__('The peminjamanmobil has been deleted.'));
        } else {
            $this->Flash->error(__('The peminjamanmobil could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
