<?php
declare(strict_types=1);

namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Peminjamanmobil Entity
 *
 * @property string $id
 * @property string $status_driver
 * @property \Cake\I18n\FrozenDate $tanggal_pinjam
 * @property \Cake\I18n\Time $waktu_pinjam
 * @property string $nama_peminjam
 * @property string $tujuan
 * @property string $deskripsi
 * @property string $penumpang
 * @property \Cake\I18n\FrozenTime $created
 * @property string $id_departemen
 * @property string $id_lokasi
 * @property string $id_driver
 * @property string $id_mobil
 */
class Peminjamanmobil extends Entity
{
    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array<string, bool>
     */
    protected $_accessible = [
        'status_driver' => true,
        'tanggal_pinjam' => true,
        'waktu_pinjam' => true,
        'nama_peminjam' => true,
        'deskripsi' => true,
        'penumpang' => true,
        'created' => true,
        'id_departemen' => true,
        'id_lokasi' => true,
        'id_driver' => true,
        'id_mobil' => true,
    ];
}
