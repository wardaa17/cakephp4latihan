<?php
declare(strict_types=1);

namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Peminjamanruang Entity
 *
 * @property string $id_ruang
 * @property string $nama_peminjam
 * @property \Cake\I18n\FrozenDate $tanggal_pakai
 * @property \Cake\I18n\Time $waktu_pakai
 * @property int $waktu_selesai
 * @property int $tujuan
 * @property int $jumlah_pengguna
 * @property string $status
 * @property int $penginput
 * @property int $email
 */
class Peminjamanruang extends Entity
{
    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array<string, bool>
     */
    protected $_accessible = [
        'id_ruang' => true,
        'id_departemen' => true,
        'nama_peminjam' => true,
        'tanggal_pakai' => true,
        'waktu_pakai' => true,
        'waktu_selesai' => true,
        'tujuan' => true,
        'jumlah_pengguna' => true,
        'status' => true,
        'penginput' => true,
        'email' => true,
    ];

    protected $hidden =['departemen','ruangan'];
}
