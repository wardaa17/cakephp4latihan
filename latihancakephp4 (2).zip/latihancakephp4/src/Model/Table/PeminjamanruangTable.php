<?php
declare(strict_types=1);

namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Peminjamanruang Model
 *
 * @method \App\Model\Entity\Peminjamanruang newEmptyEntity()
 * @method \App\Model\Entity\Peminjamanruang newEntity(array $data, array $options = [])
 * @method \App\Model\Entity\Peminjamanruang[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Peminjamanruang get($primaryKey, $options = [])
 * @method \App\Model\Entity\Peminjamanruang findOrCreate($search, ?callable $callback = null, $options = [])
 * @method \App\Model\Entity\Peminjamanruang patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Peminjamanruang[] patchEntities(iterable $entities, array $data, array $options = [])
 * @method \App\Model\Entity\Peminjamanruang|false save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Peminjamanruang saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Peminjamanruang[]|\Cake\Datasource\ResultSetInterface|false saveMany(iterable $entities, $options = [])
 * @method \App\Model\Entity\Peminjamanruang[]|\Cake\Datasource\ResultSetInterface saveManyOrFail(iterable $entities, $options = [])
 * @method \App\Model\Entity\Peminjamanruang[]|\Cake\Datasource\ResultSetInterface|false deleteMany(iterable $entities, $options = [])
 * @method \App\Model\Entity\Peminjamanruang[]|\Cake\Datasource\ResultSetInterface deleteManyOrFail(iterable $entities, $options = [])
 */
class PeminjamanruangTable extends Table
{
    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config): void
    {
        parent::initialize($config);

        $this->setTable('peminjamanruang');
        $this->setDisplayField('nama_peminjam');
        $this->setPrimaryKey('id');
        $this->belongsTo('Ruangans', [
            'foreignKey' => 'id_ruang',
            'joinType' => 'INNER']);
            $this->belongsTo('Departemens', [
                'foreignKey' => 'id_departemen',
                'joinType' => 'INNER']);
    }
   
    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator): Validator
    {
        $validator
            ->scalar('nama_peminjam')
            ->maxLength('nama_peminjam', 100)
            ->requirePresence('nama_peminjam', 'create')
            ->notEmptyString('nama_peminjam');

        $validator
            ->date('tanggal_pakai')
            ->requirePresence('tanggal_pakai', 'create')
            ->notEmptyDate('tanggal_pakai');

        $validator
            ->time('waktu_pakai')
            ->requirePresence('waktu_pakai', 'create')
            ->notEmptyTime('waktu_pakai');

        $validator
            ->integer('waktu_selesai')
            ->requirePresence('waktu_selesai', 'create')
            ->notEmptyString('waktu_selesai');

        $validator
            ->integer('tujuan')
            ->requirePresence('tujuan', 'create')
            ->notEmptyString('tujuan');

        $validator
            ->integer('jumlah_pengguna')
            ->requirePresence('jumlah_pengguna', 'create')
            ->notEmptyString('jumlah_pengguna');

        $validator
            ->scalar('status')
            ->requirePresence('status', 'create')
            ->notEmptyString('status');

        $validator
            ->integer('penginput')
            ->requirePresence('penginput', 'create')
            ->notEmptyString('penginput');

        $validator
            ->email('email')
            ->requirePresence('email', 'create')
            ->notEmptyString('email');

        return $validator;
    }
}
