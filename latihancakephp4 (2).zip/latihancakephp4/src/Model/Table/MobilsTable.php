<?php
declare(strict_types=1);

namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Mobils Model
 *
 * @method \App\Model\Entity\Mobil newEmptyEntity()
 * @method \App\Model\Entity\Mobil newEntity(array $data, array $options = [])
 * @method \App\Model\Entity\Mobil[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Mobil get($primaryKey, $options = [])
 * @method \App\Model\Entity\Mobil findOrCreate($search, ?callable $callback = null, $options = [])
 * @method \App\Model\Entity\Mobil patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Mobil[] patchEntities(iterable $entities, array $data, array $options = [])
 * @method \App\Model\Entity\Mobil|false save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Mobil saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Mobil[]|\Cake\Datasource\ResultSetInterface|false saveMany(iterable $entities, $options = [])
 * @method \App\Model\Entity\Mobil[]|\Cake\Datasource\ResultSetInterface saveManyOrFail(iterable $entities, $options = [])
 * @method \App\Model\Entity\Mobil[]|\Cake\Datasource\ResultSetInterface|false deleteMany(iterable $entities, $options = [])
 * @method \App\Model\Entity\Mobil[]|\Cake\Datasource\ResultSetInterface deleteManyOrFail(iterable $entities, $options = [])
 */
class MobilsTable extends Table
{
    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config): void
    {
        parent::initialize($config);

        $this->setTable('mobils');
        $this->setDisplayField('nopol_mobil');
        $this->setPrimaryKey('id');
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator): Validator
    {
        $validator
            ->scalar('nopol_mobil')
            ->maxLength('nopol_mobil', 100)
            ->requirePresence('nopol_mobil', 'create')
            ->notEmptyString('nopol_mobil');

        $validator
            ->scalar('nama_mobil')
            ->maxLength('nama_mobil', 100)
            ->requirePresence('nama_mobil', 'create')
            ->notEmptyString('nama_mobil');

        $validator
            ->scalar('type_mobil')
            ->maxLength('type_mobil', 100)
            ->requirePresence('type_mobil', 'create')
            ->notEmptyString('type_mobil');

        $validator
            ->integer('kapasitas')
            ->requirePresence('kapasitas', 'create')
            ->notEmptyString('kapasitas');

        return $validator;
    }
}
