<?php
declare(strict_types=1);

namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Peminjamanmobil Model
 *
 * @method \App\Model\Entity\Peminjamanmobil newEmptyEntity()
 * @method \App\Model\Entity\Peminjamanmobil newEntity(array $data, array $options = [])
 * @method \App\Model\Entity\Peminjamanmobil[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Peminjamanmobil get($primaryKey, $options = [])
 * @method \App\Model\Entity\Peminjamanmobil findOrCreate($search, ?callable $callback = null, $options = [])
 * @method \App\Model\Entity\Peminjamanmobil patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Peminjamanmobil[] patchEntities(iterable $entities, array $data, array $options = [])
 * @method \App\Model\Entity\Peminjamanmobil|false save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Peminjamanmobil saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Peminjamanmobil[]|\Cake\Datasource\ResultSetInterface|false saveMany(iterable $entities, $options = [])
 * @method \App\Model\Entity\Peminjamanmobil[]|\Cake\Datasource\ResultSetInterface saveManyOrFail(iterable $entities, $options = [])
 * @method \App\Model\Entity\Peminjamanmobil[]|\Cake\Datasource\ResultSetInterface|false deleteMany(iterable $entities, $options = [])
 * @method \App\Model\Entity\Peminjamanmobil[]|\Cake\Datasource\ResultSetInterface deleteManyOrFail(iterable $entities, $options = [])
 */
class PeminjamanmobilTable extends Table
{
    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config): void
    {
        parent::initialize($config);

        $this->setTable('peminjamanmobil');
        $this->setDisplayField('status_driver');
        $this->setPrimaryKey('id');

        $this->belongsTo('Departemens', [
            'foreignKey' => 'id_departemen',
            'joinType' =>'INNER',
        ]);

        $this->belongsTo('Lokasis', [
            'foreignKey' => 'id_lokasi',
            'joinType' =>'INNER',
        ]);

        $this->belongsTo('Drivers', [
            'foreignKey' => 'id_driver',
            'joinType' =>'INNER',
        ]);

        $this->belongsTo('Mobils', [
            'foreignKey' => 'id_mobil',
            'joinType' =>'INNER',
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator): Validator
    {
        $validator
            ->scalar('status_driver')
            ->maxLength('status_driver', 50)
            ->requirePresence('status_driver', 'create')
            ->notEmptyString('status_driver');

        $validator
            ->date('tanggal_pinjam')
            ->requirePresence('tanggal_pinjam', 'create')
            ->notEmptyDate('tanggal_pinjam');

        $validator
            ->time('waktu_pinjam')
            ->requirePresence('waktu_pinjam', 'create')
            ->notEmptyTime('waktu_pinjam');

        $validator
            ->scalar('nama_peminjam')
            ->maxLength('nama_peminjam', 50)
            ->requirePresence('nama_peminjam', 'create')
            ->notEmptyString('nama_peminjam');
            
        $validator
            ->scalar('deskripsi')
            ->requirePresence('deskripsi', 'create')
            ->notEmptyString('deskripsi');

        $validator
            ->scalar('created')
            ->requirePresence('created', 'create')
            ->notEmptyString('created');

        $validator
            ->scalar('penumpang')
            ->maxLength('penumpang', 50)
            ->requirePresence('penumpang', 'create')
            ->notEmptyString('penumpang');

        $validator
            ->uuid('id_departemen')
            ->requirePresence('id_departemen', 'create')
            ->notEmptyString('id_departemen');

        $validator
            ->uuid('id_lokasi')
            ->requirePresence('id_lokasi', 'create')
            ->notEmptyString('id_lokasi');

        $validator
            ->uuid('id_driver')
            ->requirePresence('id_driver', 'create')
            ->notEmptyString('id_driver');

        $validator
            ->uuid('id_mobil')
            ->requirePresence('id_mobil', 'create')
            ->notEmptyString('id_mobil');

        return $validator;
    }
}
