<?php
declare(strict_types=1);

namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * PeminjamanmobilFixture
 */
class PeminjamanmobilFixture extends TestFixture
{
    /**
     * Table name
     *
     * @var string
     */
    public $table = 'peminjamanmobil';
    /**
     * Init method
     *
     * @return void
     */
    public function init(): void
    {
        $this->records = [
            [
                'id' => '96172448-b630-4f05-a561-317651932ab3',
                'status_driver' => 'Lorem ipsum dolor sit amet',
                'tanggal_pinjam' => '2024-03-08',
                'waktu_pinjam' => '02:33:04',
                'nama_peminjam' => 'Lorem ipsum dolor sit amet',
                'tujuan' => 'Lorem ipsum dolor sit amet',
                'deskripsi' => 'Lorem ipsum dolor sit amet, aliquet feugiat. Convallis morbi fringilla gravida, phasellus feugiat dapibus velit nunc, pulvinar eget sollicitudin venenatis cum nullam, vivamus ut a sed, mollitia lectus. Nulla vestibulum massa neque ut et, id hendrerit sit, feugiat in taciti enim proin nibh, tempor dignissim, rhoncus duis vestibulum nunc mattis convallis.',
                'penumpang' => 'Lorem ipsum dolor sit amet',
                'created' => '2024-03-08 02:33:04',
                'id_departemen' => 'dd2985d6-43ab-43e7-ab2f-9625a67939bb',
                'id_lokasi' => '1e59a7db-f48c-4268-bc47-546d37db942c',
                'id_driver' => 'd11630d6-0a33-4bac-905f-506f45f4881c',
                'id_mobil' => 'f8da0640-49ec-4c76-8494-4568244819fd',
            ],
        ];
        parent::init();
    }
}
