<?php
declare(strict_types=1);

namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * AplikasimeetingFixture
 */
class AplikasimeetingFixture extends TestFixture
{
    /**
     * Table name
     *
     * @var string
     */
    public $table = 'aplikasimeeting';
    /**
     * Init method
     *
     * @return void
     */
    public function init(): void
    {
        $this->records = [
            [
                'id' => 1,
                'nama_aplikasi' => 'Lorem ipsum dolor sit amet',
                'tanggal' => '2024-03-05',
                'waktu_mulai' => '08:45:49',
                'waktu_selesai' => '08:45:49',
            ],
        ];
        parent::init();
    }
}
