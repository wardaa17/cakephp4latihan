<?php
declare(strict_types=1);

namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * DepartemensFixture
 */
class DepartemensFixture extends TestFixture
{
    /**
     * Init method
     *
     * @return void
     */
    public function init(): void
    {
        $this->records = [
            [
                'id' => '8acbea1e-84fb-4767-bf4c-c5a83630e6b5',
                'departemen' => 'Lorem ipsum dolor sit amet',
            ],
        ];
        parent::init();
    }
}
