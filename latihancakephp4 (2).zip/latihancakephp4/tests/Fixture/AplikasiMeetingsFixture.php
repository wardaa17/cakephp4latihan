<?php
declare(strict_types=1);

namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * AplikasiMeetingsFixture
 */
class AplikasiMeetingsFixture extends TestFixture
{
    /**
     * Init method
     *
     * @return void
     */
    public function init(): void
    {
        $this->records = [
            [
                'id' => 'c7dc33aa-6022-42f0-9c6f-d7940aab6f73',
                'nama_aplikasi' => 'Lorem ipsum dolor sit amet',
                'tanggal' => '2024-03-05',
                'waktu_mulai' => '06:38:14',
                'waktu_selesai' => '06:38:14',
            ],
        ];
        parent::init();
    }
}
