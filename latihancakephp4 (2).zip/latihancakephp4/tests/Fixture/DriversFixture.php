<?php
declare(strict_types=1);

namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * DriversFixture
 */
class DriversFixture extends TestFixture
{
    /**
     * Init method
     *
     * @return void
     */
    public function init(): void
    {
        $this->records = [
            [
                'id' => 1,
                'nama' => 'Lorem ipsum dolor sit amet',
                'umur' => 1,
                'jenis_kelamin' => 'Lorem ipsum dolor sit amet',
                'alamat' => 'Lorem ipsum dolor sit amet',
            ],
        ];
        parent::init();
    }
}
