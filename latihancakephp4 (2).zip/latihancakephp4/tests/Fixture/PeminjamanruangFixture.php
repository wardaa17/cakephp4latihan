<?php
declare(strict_types=1);

namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * PeminjamanruangFixture
 */
class PeminjamanruangFixture extends TestFixture
{
    /**
     * Table name
     *
     * @var string
     */
    public $table = 'peminjamanruang';
    /**
     * Init method
     *
     * @return void
     */
    public function init(): void
    {
        $this->records = [
            [
                'id_ruang' => '2bffff98-a09d-4301-9b04-cc17971b8dfc',
                'nama_peminjam' => 'Lorem ipsum dolor sit amet',
                'tanggal_pakai' => '2024-03-08',
                'waktu_pakai' => '02:38:04',
                'waktu_selesai' => 1,
                'tujuan' => 1,
                'jumlah_pengguna' => 1,
                'status' => 'Lorem ipsum dolor sit amet',
                'penginput' => 1,
                'email' => 1,
            ],
        ];
        parent::init();
    }
}
