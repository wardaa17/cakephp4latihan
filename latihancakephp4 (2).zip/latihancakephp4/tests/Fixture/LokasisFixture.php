<?php
declare(strict_types=1);

namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * LokasisFixture
 */
class LokasisFixture extends TestFixture
{
    /**
     * Table name
     *
     * @var string
     */
    public $table = 'lokasis';
    /**
     * Init method
     *
     * @return void
     */
    public function init(): void
    {
        $this->records = [
            [
                'id' => '7ed45c6a-b53f-47de-affa-26fb638d479e',
                'nama_lokasi' => 'Lorem ipsum dolor sit amet',
            ],
        ];
        parent::init();
    }
}
