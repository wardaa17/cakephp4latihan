<?php
declare(strict_types=1);

namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * UsersFixture
 */
class UsersFixture extends TestFixture
{
    /**
     * Init method
     *
     * @return void
     */
    public function init(): void
    {
        $this->records = [
            [
                'id' => 'b51dd7f6-d552-40b9-a465-fda6de8d64ee',
                'email' => 'Lorem ipsum dolor sit amet',
                'password' => 'Lorem ipsum dolor sit amet',
                'no_hp' => 'Lorem ipsum dolor sit amet',
                'created' => '2024-03-06 03:44:07',
            ],
        ];
        parent::init();
    }
}
