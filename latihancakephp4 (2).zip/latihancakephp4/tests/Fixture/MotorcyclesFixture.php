<?php
declare(strict_types=1);

namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * MotorcyclesFixture
 */
class MotorcyclesFixture extends TestFixture
{
    /**
     * Init method
     *
     * @return void
     */
    public function init(): void
    {
        $this->records = [
            [
                'id' => 1,
                'motor_code' => 'Lorem ip',
                'motor_name' => 'Lorem ipsum dolor sit amet',
                'created' => '2024-03-05 04:36:00',
            ],
        ];
        parent::init();
    }
}
