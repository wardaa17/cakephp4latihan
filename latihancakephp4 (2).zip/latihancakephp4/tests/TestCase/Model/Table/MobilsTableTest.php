<?php
declare(strict_types=1);

namespace App\Test\TestCase\Model\Table;

use App\Model\Table\MobilsTable;
use Cake\TestSuite\TestCase;

/**
 * App\Model\Table\MobilsTable Test Case
 */
class MobilsTableTest extends TestCase
{
    /**
     * Test subject
     *
     * @var \App\Model\Table\MobilsTable
     */
    protected $Mobils;

    /**
     * Fixtures
     *
     * @var array<string>
     */
    protected $fixtures = [
        'app.Mobils',
    ];

    /**
     * setUp method
     *
     * @return void
     */
    protected function setUp(): void
    {
        parent::setUp();
        $config = $this->getTableLocator()->exists('Mobils') ? [] : ['className' => MobilsTable::class];
        $this->Mobils = $this->getTableLocator()->get('Mobils', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    protected function tearDown(): void
    {
        unset($this->Mobils);

        parent::tearDown();
    }

    /**
     * Test validationDefault method
     *
     * @return void
     * @uses \App\Model\Table\MobilsTable::validationDefault()
     */
    public function testValidationDefault(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
