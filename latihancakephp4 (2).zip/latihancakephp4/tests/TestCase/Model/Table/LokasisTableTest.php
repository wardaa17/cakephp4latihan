<?php
declare(strict_types=1);

namespace App\Test\TestCase\Model\Table;

use App\Model\Table\LokasisTable;
use Cake\TestSuite\TestCase;

/**
 * App\Model\Table\LokasisTable Test Case
 */
class LokasisTableTest extends TestCase
{
    /**
     * Test subject
     *
     * @var \App\Model\Table\LokasisTable
     */
    protected $Lokasis;

    /**
     * Fixtures
     *
     * @var array<string>
     */
    protected $fixtures = [
        'app.Lokasis',
    ];

    /**
     * setUp method
     *
     * @return void
     */
    protected function setUp(): void
    {
        parent::setUp();
        $config = $this->getTableLocator()->exists('Lokasis') ? [] : ['className' => LokasisTable::class];
        $this->Lokasis = $this->getTableLocator()->get('Lokasis', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    protected function tearDown(): void
    {
        unset($this->Lokasis);

        parent::tearDown();
    }

    /**
     * Test validationDefault method
     *
     * @return void
     * @uses \App\Model\Table\LokasisTable::validationDefault()
     */
    public function testValidationDefault(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
