<?php
declare(strict_types=1);

namespace App\Test\TestCase\Model\Table;

use App\Model\Table\DepartemensTable;
use Cake\TestSuite\TestCase;

/**
 * App\Model\Table\DepartemensTable Test Case
 */
class DepartemensTableTest extends TestCase
{
    /**
     * Test subject
     *
     * @var \App\Model\Table\DepartemensTable
     */
    protected $Departemens;

    /**
     * Fixtures
     *
     * @var array<string>
     */
    protected $fixtures = [
        'app.Departemens',
    ];

    /**
     * setUp method
     *
     * @return void
     */
    protected function setUp(): void
    {
        parent::setUp();
        $config = $this->getTableLocator()->exists('Departemens') ? [] : ['className' => DepartemensTable::class];
        $this->Departemens = $this->getTableLocator()->get('Departemens', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    protected function tearDown(): void
    {
        unset($this->Departemens);

        parent::tearDown();
    }

    /**
     * Test validationDefault method
     *
     * @return void
     * @uses \App\Model\Table\DepartemensTable::validationDefault()
     */
    public function testValidationDefault(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
