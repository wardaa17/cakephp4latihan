<?php
declare(strict_types=1);

namespace App\Test\TestCase\Model\Table;

use App\Model\Table\AplikasiMeetingsTable;
use Cake\TestSuite\TestCase;

/**
 * App\Model\Table\AplikasiMeetingsTable Test Case
 */
class AplikasiMeetingsTableTest extends TestCase
{
    /**
     * Test subject
     *
     * @var \App\Model\Table\AplikasiMeetingsTable
     */
    protected $AplikasiMeetings;

    /**
     * Fixtures
     *
     * @var array<string>
     */
    protected $fixtures = [
        'app.AplikasiMeetings',
    ];

    /**
     * setUp method
     *
     * @return void
     */
    protected function setUp(): void
    {
        parent::setUp();
        $config = $this->getTableLocator()->exists('AplikasiMeetings') ? [] : ['className' => AplikasiMeetingsTable::class];
        $this->AplikasiMeetings = $this->getTableLocator()->get('AplikasiMeetings', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    protected function tearDown(): void
    {
        unset($this->AplikasiMeetings);

        parent::tearDown();
    }

    /**
     * Test validationDefault method
     *
     * @return void
     * @uses \App\Model\Table\AplikasiMeetingsTable::validationDefault()
     */
    public function testValidationDefault(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
