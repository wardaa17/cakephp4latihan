<?php
declare(strict_types=1);

namespace App\Test\TestCase\Model\Table;

use App\Model\Table\PeminjamanmobilTable;
use Cake\TestSuite\TestCase;

/**
 * App\Model\Table\PeminjamanmobilTable Test Case
 */
class PeminjamanmobilTableTest extends TestCase
{
    /**
     * Test subject
     *
     * @var \App\Model\Table\PeminjamanmobilTable
     */
    protected $Peminjamanmobil;

    /**
     * Fixtures
     *
     * @var array<string>
     */
    protected $fixtures = [
        'app.Peminjamanmobil',
    ];

    /**
     * setUp method
     *
     * @return void
     */
    protected function setUp(): void
    {
        parent::setUp();
        $config = $this->getTableLocator()->exists('Peminjamanmobil') ? [] : ['className' => PeminjamanmobilTable::class];
        $this->Peminjamanmobil = $this->getTableLocator()->get('Peminjamanmobil', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    protected function tearDown(): void
    {
        unset($this->Peminjamanmobil);

        parent::tearDown();
    }

    /**
     * Test validationDefault method
     *
     * @return void
     * @uses \App\Model\Table\PeminjamanmobilTable::validationDefault()
     */
    public function testValidationDefault(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
